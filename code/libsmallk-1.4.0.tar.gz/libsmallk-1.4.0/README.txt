Documentation for SmallK (including build and installation instructions) 
can be found in doc/smallk_readme.pdf.
